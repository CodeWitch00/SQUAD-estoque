# Figuras do SQUAD Estoque para a monografia

**Implementação conferida:** commit `26f042289596a3785a4624e4ed9a82d2888c0175` (`main`, 23/11/2026). O pacote foi montado localmente, sem consultar ou alterar o Azure. As oito capturas de interface foram produzidas anteriormente sobre o commit `dcb6c488b58d88363f6ba2d881b43783f9c14560`; ver `interfaces/README.md` para ambiente, rotas, viewports e limitações. Essas imagens não foram retocadas.

## Diagramas

| Arquivo | Figura | Dimensão PNG | Inserção sugerida A4 retrato |
| --- | --- | ---: | ---: |
| `diagramas/01-casos-de-uso.png` | Casos de uso | 1890 × 2468 px | 16 × 20,9 cm |
| `diagramas/02-classe-catalogo-atendimento.png` | Classes: catálogo e atendimento | 1890 × 2605 px | 16 × 22,1 cm |
| `diagramas/03-classe-entrada-fiscal.png` | Classes: entrada fiscal | 1890 × 3316 px | 13,2 × 23,2 cm |
| `diagramas/04-sequencia-venda.png` | Sequência da venda bem-sucedida | 1890 × 1638 px | 16 × 13,9 cm |
| `diagramas/05-der-catalogo-atendimento.png` | DER: catálogo e atendimento | 1890 × 1980 px | 16 × 16,8 cm |
| `diagramas/06-der-entrada-fiscal.png` | DER: entrada fiscal | 1890 × 2096 px | 16 × 17,7 cm |

Cada PNG possui SVG de mesmo nome. A exportação com 1890 px de largura equivale a 300 DPI quando a figura é inserida com 16 cm; a visão de classes fiscal, inserida com 13,2 cm, tem densidade maior. As medidas preservam a largura útil de 16 cm do A4 retrato com margens esquerda de 3 cm e direita de 2 cm; a altura útil de 24,7 cm deve comportar também título e fonte da figura.

## Revisões e conferências

- **Casos de uso:** separadas a seleção de SKU e a retomada de pendência; separadas a importação de XML e a confirmação da entrada fiscal; organizadas as operações efetivas do LOJISTA e VENDEDOR. Login e logout aparecem para ambos. A figura não atribui ao banco ou aos controllers o papel de ator.
- **Classes de catálogo e atendimento:** mantida a figura conceitualmente aprovada. Conferidos `Atendimento.Status`, `Resultado`, `SaldoConsultado`, datas, enumerações C# e as coleções `Produto.Skus`, `Sku.Movimentacoes` e `Sku.Rupturas`.
- **Classes de entrada fiscal:** mantida a figura conceitualmente aprovada. Conferidas as seis classes, os tipos C# e as cinco associações, inclusive FKs opcionais `Guid?`, `DateTime?`, `decimal` e `ICollection<ItemEntradaFiscal>`.
- **Sequência:** mantida a figura de venda bem-sucedida. A criação opcional de pendência fica antes da transação; dentro dela, ocorre revalidação, atualização condicional do saldo, movimentação `SAIDA`, conclusão do atendimento, `SaveChanges` e `Commit`.
- **DER de catálogo e atendimento:** acrescentados atributos físicos essenciais, ajustadas as dez cardinalidades e as linhas tracejadas de relacionamentos não identificadores. A fonte Graphviz DOT produz a figura compacta; a fonte Mermaid equivalente permanece no repositório para conferência estrutural.
- **DER de entrada fiscal:** acrescentados atributos físicos essenciais, ajustadas as cinco cardinalidades e as linhas tracejadas. Fonte Mermaid e SVG conferidos visualmente.

As duas visões de classes representam, juntas, as nove classes persistidas; as duas visões do DER representam as nove tabelas e os quinze relacionamentos do `EstoqueContext`. `Usuario`, `Produto` e `Sku` repetem-se nas visões por contexto visual. As figuras selecionam atributos para leitura; as definições completas permanecem no código, nas migrations e no ModelSnapshot. Nos DERs, GUID e datas são `TEXT`, inteiros, enumerações e booleanos são `INTEGER`. As FKs opcionais são `Atendimento.SkuId`, `Movimentacao.AtendimentoId`, `Ruptura.AtendimentoId`, `ItemEntradaFiscal.ProdutoId` e `ItemEntradaFiscal.SkuId`.

Restrições físicas conferidas: unicidade de `Usuario.Email` e `EntradaFiscal.ChaveAcesso`; unicidade composta de `Sku(ProdutoId, Numeracao)` e `VinculoProdutoFornecedor(CnpjFornecedor, CodigoFornecedor)`; unicidade dos vínculos opcionais de movimentação e ruptura a atendimento; `CHECK` de saldo não negativo, quantidade de movimentação positiva e domínios/consistência de atendimento. `ItemEntradaFiscal.EntradaFiscalId` usa `CASCADE`; as demais FKs configuradas usam `RESTRICT`. Imutabilidade do histórico depende das operações da aplicação e não foi atribuída ao SQLite como constraint.

## Fontes e limites

Fontes técnicas: `src/SquadEstoque.Web/Models/Entities/`, `src/SquadEstoque.Web/Controllers/`, `src/SquadEstoque.Web/Data/EstoqueContext.cs`, `src/SquadEstoque.Web/Data/SaidaEstoque.cs`, `src/SquadEstoque.Web/Migrations/Estoque/`, `docs/02-requisitos/srs.md`, `docs/02-requisitos/casos-de-uso.md` e os arquivos-fonte em `docs/06-uml/`. O DER acadêmico antigo de cinco tabelas em `docs/03-modelagem/` permanece histórico, não vigente.

As fontes Mermaid foram submetidas ao renderizador temporário, os seis SVGs foram exportados a PNG e as seis imagens foram inspecionadas. A visão fiscal de classes é a mais densa; convém conferir a prova impressa antes de inserir no DOCX. Nenhuma captura de interface nova nem teste funcional da aplicação foi executado nesta consolidação. A documentação textual de casos de uso e a modelagem histórica contêm descrições mais antigas; o diagrama atualizado segue as rotas e permissões do código vigente. Não se deve interpretar a figura de sequência como garantia de rollback da pendência criada antes da transação.
